<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

if (isset($_POST['submit'])){


	include_once 'dbh.inc.php';
	$fname=$_POST['first'];
	$lname=$_POST['last'];
	$email=$_POST['email'];
	$userid=$_POST['uid'];
	$password=$_POST['pwd'];
	$first = mysqli_real_escape_string($conn, $fname);
	$last = mysqli_real_escape_string($conn, $lname);
	$email = mysqli_real_escape_string($conn, $email);
	$uid = htmlspecialchars(mysqli_real_escape_string($conn, $userid));
	$pwd = mysqli_real_escape_string($conn, $password);
	$connection = new AMQPStreamConnection('localhost', 5672, 'guest', 'guest');
	$channel = $connection->channel();
	$channel->queue_declare('first', false, false, false, false);
	$channel->queue_declare('last', false, false, false, false);
	$channel->queue_declare('email', false, false, false, false);
	$channel->queue_declare('uid', false, false, false, false);
	$channel->queue_declare('pwd', false, false, false, false);

	if (empty($first) || empty($last) || empty($email)|| empty($uid)|| empty($pwd)){
		header("Location: ../signup.php?signup=empty");
		// error statement
		exit();
	} else {

		//check if input charecters are valid
		if (!preg_match("/^[a-zA-Z]*$/", $first) || !preg_match("/^[a-zA-Z]*$/", $last)){
			header("Location: ../signup.php?signup=invalid");
			// error statement
			exit();
		} else {
			//check if email is valid
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
				header("Location: ../signup.php?signup=email&first=$first&last=$last&uid=$uid");
				//error statement
				//exit();
			} else {
				$sql = "SELECT * FROM users WHERE user_uid='$uid'";
				$result = mysqli_query($conn, $sql);
				$resultCheck = mysqli_num_rows($result);

				if ($resultCheck > 0){
					header("Location: ../signup.php?signup=usertaken");
					exit();
				} else {
					//hashing the password
					$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
					//insert the user into the database
					//$sql = "INSERT INTO users (user_first, user_last, user_email, user_uid, user_pwd) VALUES ('$first', '$last', '$email', '$uid', '$hashedPwd');";
					//mysqli_query($conn, $sql);
					header("Location: ../signup.php?signup=success");
					$msg = new AMQPMessage($first);
					$channel->basic_publish($msg, '', 'first');

					$msg2 = new AMQPMessage($last);
					$channel->basic_publish($msg2, '', 'last');


					$msg3 = new AMQPMessage($email);
					$channel->basic_publish($msg3, '', 'email');


					$msg4 = new AMQPMessage($uid);
					$channel->basic_publish($msg4, '', 'uid');


					$msg5 = new AMQPMessage($hashedPwd);
					$channel->basic_publish($msg5, '', 'pwd');

					echo " [x] Sent....!'\n";
					$channel->close();
					$connection->close();
					exit();
				}

			}
		}
	}


	

} else {
	header("Location: ../signup.php");
	exit();
}

<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;
session_start();

if (isset($_POST['submit'])){
	include 'dbh.inc.php';
	$userid=$_POST['uid'];
	$password=$_POST['pwd'];
	
	$uid = mysqli_real_escape_string($conn, $userid);
	$pwd = mysqli_real_escape_string($conn, $password);
	$connection = new AMQPStreamConnection('localhost', 5672, 'guest', 'guest');
	$channel = $connection->channel();
	$channel->queue_declare('uname', false, false, false, false);

	//error handlers
	//check if inputs are empty
	if (empty($uid) || empty($pwd)){
		header("Location: ../index.php?login=empty");
		exit();
	} else {
		$sql = "SELECT * FROM users WHERE user_uid='$uid'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		if ($resultCheck < 1){
			header("Location: ../index.php?login=error");
		exit();
		} else {
			if ($row = mysqli_fetch_assoc($result)){
				//de-hashing the password
				$hashedPwdCheck = password_verify($pwd, $row['user_pwd']);
				if ($hashedPwdCheck == false) {
					header("Location: ../index.php?login=error");
					exit();
				} elseif ($hashedPwdCheck == true) {
					//log in the user here
					$_SESSION['u_id'] = $row['user_id'];
					$_SESSION['u_first'] = $row['user_first'];
					$_SESSION['u_last'] = $row['user_last'];
					$_SESSION['u_email'] = $row['user_email'];
					$_SESSION['u_uid'] = $row['user_uid'];
					header("Location: ../index.php?login=success");
					$msg = new AMQPMessage($uname);
					$channel->basic_publish($msg, '', 'uname');
					echo " [x] Request sent'\n";
					$channel->close();
					$connection->close();
					exit();
				}
			}
		}
	} 
} else {
		header("Location: ../index.php?login=error");
		exit();	
}

<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "Master@1234";
$dbName = "mihad";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
